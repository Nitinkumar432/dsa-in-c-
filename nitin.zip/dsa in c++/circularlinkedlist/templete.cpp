#include<iostream>
using namespace std;
templete<typename T>
class node{
    public:
    T val;
    node*next;
    node(int v){
        this->val=v;
        next=NULL;
    }
}
int main(){
node<int>*node1=new node<int>(3);
cout<<node1->val<<endl;

}