#include<iostream>
using namespace std;
class node{
    public:
    int val;
    node*next;
    node(int v){
        val=v;
        next=NULL;
    }
};
void insertatstart(node*&head,int n){
    node*newn=new node(n);
    if(head==NULL){
        head=newn;
        newn->next=head;
        return ;
    }
    node*tail=head;
    while(tail->next!=head){
        tail=tail->next;

    }
    //now tail to poninting last node
    tail->next=newn;
    newn->next=head;
    head=newn;

}
void display(node*head){
    node*temp=head;
    do{
        cout<<temp->val<<" ";
        temp=temp->next;

    }while(temp!=head);

}
int main(){
    node*cll=NULL;
    insertatstart(cll,10);
    insertatstart(cll,20);
    insertatstart(cll,30);
    insertatstart(cll,40);
    insertatstart(cll,50);
    insertatstart(cll,60);
    display(cll);
    
    
}