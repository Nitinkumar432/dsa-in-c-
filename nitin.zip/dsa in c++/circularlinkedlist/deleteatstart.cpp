#include<iostream>
using namespace std;
class node{
    public:
    int val;
    node*next;
    node(int v){
        val=v;
        next=NULL;
    }
};
void insertatend(node*&head,int n){
    node*newn=new node(n);
    if(head==NULL){
        head=newn;
        newn->next=head;
        return ;
    }
    node*tail=head;
    while(tail->next!=head){
        tail=tail->next;

    }
    //now tail to poninting last node
    tail->next=newn;
    newn->next=head;
    
    
}
void deleteathead(node*&head){
    if(head==NULL){
        return ;
    }
    node*tail=head;
    while(tail->next!=head){
        tail=tail->next;
    }
    
        head=head->next;
        tail->next=head;
        cout<<"value of tail : " <<tail->val<<endl;
    
}
void display(node*head){
    node*temp=head;
    do{
        cout<<temp->val<<" ";
        temp=temp->next;

    }while(temp!=head);

}
int main(){
    node*cll=NULL;
    insertatend(cll,10);
    insertatend(cll,20);
    insertatend(cll,30);
    insertatend(cll,40);
    insertatend(cll,50);
    insertatend(cll,60);
    deleteathead(cll);
    display(cll);
    
    
}