#include<iostream>
#include<list>
using namespace std;

int main(){
    list<int>list1={1,2,3,4,5,6};
    auto itr=list1.begin();
    advance(itr,2);
    list1.insert(itr,3,100);
    for(auto i : list1){
        cout<<i<<endl;
    }
    // auto l=list1.begin();
    // auto  r=list1.begin();
    // advance(r,4);
    // list1.insert(itr ,l,r);
    // for(int i : list1){
    //     cout<<i<<endl;
// }

    //we have 5 no of times wen want insert5  4times sequencelly

}