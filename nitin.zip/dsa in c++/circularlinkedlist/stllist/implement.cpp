#include<iostream>
#include<list>

using namespace std;
int main(){
    list<int>rollno;
    //intialize llist in code
    //1 ways
    list<int>list1={1,2,3,4};
    //2nd ways
    list<int>list2{1,2,3,4};
    auto itr=list1.begin();
    auto itr2=list1.rbegin();
    auto itr3=list1.end();
    cout<<*itr<<endl;
    cout<<*itr2<<endl;
    cout<<*itr3<<endl;
    //move forwards by two points
    advance(itr,2);
    cout<<*itr<<endl;
  cout<<"loop"<<endl;
//interator function ->     begin end -> rbegin() rend()

    for(auto    i : list1){
        cout<<i<<endl;
    }
    //*iteratoer
    cout<<"another iterator"<<endl;
    for(auto itr=list1.begin();itr!=list1.end();itr++){
        cout<<*itr<<endl;
    }
    //reverse order
    cout<<"reverse order"<<endl;
     for(auto itr=list1.rbegin();itr!=list1.rend();itr++){
        cout<<*itr<<endl;
    }
    auto itr4=list1.begin();
    advance(itr4,2);

    list1.insert(itr4,300);
    for(auto i : list1){
        cout<<i<<" ";
    }
}