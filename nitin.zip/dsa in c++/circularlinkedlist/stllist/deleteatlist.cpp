#include<iostream>
#include<list>

using namespace std;

int main(){
    list<int>m={1,2,3,4,5,6};
    // auto itr=m.begin();
    // advance(itr,2);
    // m.erase(itr);
    // for(int i : m){
    //     cout<<i<<endl;
    // }
    auto sitr=m.begin();
    auto eitr=m.begin();
    advance(eitr,3);
    m.erase(sitr,eitr);
    for(int i : m){
        cout<<i<<" ";
    }
}