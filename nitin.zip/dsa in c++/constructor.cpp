// Online C++ compiler to run C++ program online
#include <iostream>
using namespace std;
class nitin{
    public:
    nitin(){
        cout<<"contructor called\n"; //constructor called
    }
    ~nitin(){
        cout<<"destructor called"; // destructor called
    }
    
};
int main() {
    nitin n1;
 
  
    return 0;
}
