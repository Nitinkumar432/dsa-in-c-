#include<iostream>
using namespace std;

class node {
public:
    int val;
    node* prev;
    node* next;

    node(int data) : val(data), prev(nullptr), next(nullptr) {}
};
int length(node*head){
    int c=0;
    while(head!=NULL){
        head=head->next;
        c++;
    }
    return c;
}
int  palindrome(node*& head) {
    node*curr=head;
    int l=length(head);
    if(l==0 || l==1){
        return 1;
    }
    node*tail=head;
    while(tail->next!=NULL){
        tail=tail->next;
    }
    //1 2 3 4 5 6
    int c=0;
    while(c!=l/2){
        if(curr->val!=tail->val){
            return  0;
        }
        curr=curr->next;
        tail=tail->prev;
        c++;
    }
    return 1;
    
   
}

void insertAtEnd(node*& head, int n) {
    node* temp = new node(n);

    if (head == nullptr) {
        head = temp;
        return;
    }

    node* curr = head;
    while (curr->next != nullptr) {
        curr = curr->next;
    }
    curr->next = temp;
    temp->prev = curr;
}

void display(node* head) {
    node* temp = head;
    while (temp != nullptr) {
        cout << temp->val << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    node* head = nullptr;

    insertAtEnd(head, 10);
    insertAtEnd(head, 20);
    insertAtEnd(head, 300);
    insertAtEnd(head ,300);
   
    insertAtEnd(head, 20);
    insertAtEnd(head, 10);

    cout << "Original List: ";
    display(head);

    if(palindrome(head)){
        cout<<"palindrome";
    }else{
        cout<<"not palindrome";
    }

    

    return 0;
}
