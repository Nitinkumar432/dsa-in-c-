#include<iostream>
using namespace std;

class node {
public:
    int val;
    node* prev;
    node* next;

    node(int data) : val(data), prev(nullptr), next(nullptr) {}
};
int length(node*head){
    int c=0;
    while(head!=NULL){
        head=head->next;
        c++;
    }
    return c;
}
void deleten(node*&head){
    node*curr=head;
    while(curr!=NULL){
       if( curr->prev!=nullptr && curr->prev->val ==curr->val){
       // 10 20 20 300 300 20 10
         node* temp = curr->prev; // Store a pointer to the node to be deleted
            curr->prev = temp->prev; // Adjust pointers to skip the node to be deleted 20 -> 10
            if (temp->prev != nullptr) {
                temp->prev->next = curr;
            }J
            delete temp; // Delete th
       }
       curr=curr->next;
    }
}

void insertAtEnd(node*& head, int n) {
    node* temp = new node(n);

    if (head == nullptr) {
        head = temp;
        return;
    }

    node* curr = head;
    while (curr->next != nullptr) {
        curr = curr->next;
    }
    curr->next = temp;
    temp->prev = curr;
}

void display(node* head) {
    node* temp = head;
    while (temp != nullptr) {
        cout << temp->val << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    node* head = nullptr;

    insertAtEnd(head, 10);
    insertAtEnd(head, 20);
    insertAtEnd(head, 20);

    insertAtEnd(head, 300);
    insertAtEnd(head ,300);
   
    insertAtEnd(head, 20);
    insertAtEnd(head, 10);

    cout << "Original List: ";
    display(head);
    deleten(head);
    cout<<"delete neigbour "<<endl;
    display(head);

    

    return 0;
}
