#include<iostream>
using namespace std;
class node{
    public:
    int val;
    node* prev;
    node* next;
    node(int data){
        val=data;
        prev=NULL;
        next=NULL;
    }

};
// 2nd round
void insertath(node*&head,int n){ //10
    node*temp=new node(n); ///20
    if(head==NULL){
        head=temp;
        return ;
    }
    //20 -> 10
    node*curr=head;
    while(curr->next!=NULL){
        curr=curr->next;


    }
    curr->next=temp;
    
}
// void insertath(node*&head,int n){ //10
//     node*temp=new node(n); ///20
//     if(head==NULL){
//         head=temp;
//         return ;
//     }
//     head->next=temp;
//     temp->prev=head;

//     head=temp;
//     //20 -> 10

    
// }
void insertatp(node*&head,int rt,int pos){
    node*temp=new node(rt);
    int s=0;
    node*t=head;
    while(s!=pos-1){
        t=t->next;
        s++;
    }
    temp->next=t->next;
    
    t->prev=temp->prev;
    t->next=temp;
}
//1 2 3 4
void deleteatlast(node*&head){
    if(head==NULL){
        return;
    }
    if(head->next==NULL){
        head=NULL;
        return ;
    }
    node*curr=head;
    while(curr->next->next!=NULL){
        curr=curr->next;
    }
    curr->next=NULL;
    // delete curr->next;
    

    
}

void display(node*head){
    node*temp=head;
    while(temp!=NULL){
        cout<<temp->val<<" ";
        temp=temp->next;
    }
    cout<<endl;
}
int main(){
    node*m=NULL; //10

    
    insertath(m,10);
    insertath(m,20);
    insertath(m,30);
    insertath(m,40);
    insertath(m,50);
    insertatp(m,500,2);
    cout<<" before deletion"<<endl;
    display(m);
    deleteatlast(m);
    cout<<"after deletion"<<endl;
    display(m);

}