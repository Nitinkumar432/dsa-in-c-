#include<iostream>
using namespace std;
class node{
    public:
    int val;
    node*prev;
    node*next;
    node(int data){
        this->val=data;
        prev=NULL;
        next=NULL;
    }

};
class doublelinkedlist{
    public:
    node*head;
    node*tail;
    doublelinkedlist(){
        head=NULL;
        tail=NULL;
    }
};
int main(){
    node*ne=new node(3);
    doublelinkedlist dll;
    dll.head=ne;
    dll.tail=ne;
  cout<<dll.head->val<<endl;
}