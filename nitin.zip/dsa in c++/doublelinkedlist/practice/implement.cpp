#include<iostream>
using namespace std;
class node{
    public:
    int val;
    node* prev;
    node* next;
    node(int data){
        val=data;
        prev=NULL;
        next=NULL;
    }

};
//2nd round
void insertath(node*&head,int n){ //10
    node*temp=new node(n); ///20
    if(head==NULL){
        head=temp;
        return ;
    }
    //20 -> 10
    temp->next=head;
    head->prev=temp; //20
    head=temp;
}
void display(node*head){
    node*temp=head;
    while(temp!=NULL){
        cout<<temp->val<<" ";
        temp=temp->next;
    }
}
int main(){
    node*m=NULL; //10
    insertath(m,10);
    insertath(m,20);
    insertath(m,30);
    insertath(m,40);
    insertath(m,50);
    display(m);

}