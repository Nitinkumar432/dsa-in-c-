
#include<iostream>
using namespace std;

class node {
public:
    int val;
    node* prev;
    node* next;
    node(int data) {
        this->val = data;
        prev = NULL;
        next = NULL;
    }
};

void insertattail(node*& head, int v) {
    node* temp = new node(v); //200
    if (head == NULL) {
        head = temp; //100
        return;
    } 
    temp->next = head; //200 100
    head->prev = temp;
    head = temp;
}



// void deletelist(node* head) {
//     while (head != NULL) {
//         node* temp = head;
//         head = head->next;
//         delete temp;
//     }
// }
void display(node* head) {
    node* temp = head;
    while (temp != NULL) {
        cout << temp->val << " ";
        temp = temp->next;
    }
}

int main() {
    node* ne = NULL;
    insertattail(ne, 100);
    insertattail(ne,200);
    insertattail(ne,300);
    insertattail(ne,400);
    display(ne);
    // deletelist(ne); // Free memory before program ends
    return 0;
}
