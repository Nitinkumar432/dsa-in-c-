#include<iostream>
using namespace std;
class node{
    public:
    int val;
    node* prev;
    node* next;
    node(int data){
        val=data;
        prev=NULL;
        next=NULL;
    }

};
void insertath(node*& head, int n) {
    node* temp = new node(n);

    if (head == nullptr) { //10
        head = temp;
        return;
    }

    node* curr = head; //20
    while (curr->next != nullptr) {
        curr = curr->next;
    }
    curr->next = temp;//10 20
    temp->prev = curr;
}
void display(node*head){
    node*temp=head;
    while(temp!=NULL){
        cout<<temp->val<<" ";
        temp=temp->next;
    }
}
int main(){
    node*m=NULL; //10

    
    insertath(m,10);
    insertath(m,20);
    insertath(m,30);
    insertath(m,40);
    insertath(m,50);

    display(m);

}