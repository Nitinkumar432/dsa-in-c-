#include<iostream>
using namespace std;

class node {
public:
    int val;
    node* prev;
    node* next;

    node(int data) : val(data), prev(nullptr), next(nullptr) {}
};

void reverse(node*& head) {
    if (head == nullptr || head->next == nullptr) {
        // Empty list or list with only one node, no need to reverse
        return;
    }

    node* current = head;
    node* temp = nullptr;
    
    // Traverse to the tail node
    while (current != nullptr) {
        temp = current->prev;
        current->prev = current->next;
        current->next = temp;
        current = current->prev; // Move to the previous node
    }

    // Update the head pointer to point to the new head (tail of original list)
    if (temp != nullptr) {
        head = temp->prev;
    }
}

void insertAtEnd(node*& head, int n) {
    node* temp = new node(n);

    if (head == nullptr) {
        head = temp;
        return;
    }

    node* curr = head;
    while (curr->next != nullptr) {
        curr = curr->next;
    }
    curr->next = temp;
    temp->prev = curr;
}

void display(node* head) {
    node* temp = head;
    while (temp != nullptr) {
        cout << temp->val << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    node* head = nullptr;

    insertAtEnd(head, 10);
    insertAtEnd(head, 20);
    insertAtEnd(head, 30);
    insertAtEnd(head, 40);
    insertAtEnd(head, 50);

    cout << "Original List: ";
    display(head);

    reverse(head);

    cout << "Reversed List: ";
    display(head);

    return 0;
}
