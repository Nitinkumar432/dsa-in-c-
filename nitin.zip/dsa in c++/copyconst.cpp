// Online C++ compiler to run C++ program online
#include <iostream>
using  namespace std;
class m{
    private:
    int health;
    int level;
    public:
    m(int h,char rt){
        this->health=h;
        this->level=rt;
    }
    void print(){
        cout<<"health : "<<this->health<<endl;
        cout<<"health : "<<this->level<<endl;
    }
    
};
int main() {
    m ritesh(100,'C');
    ritesh.print();
    m nitesh(ritesh);
    nitesh.print();
    // nitesh(ritesh);
  


    return 0;
}
