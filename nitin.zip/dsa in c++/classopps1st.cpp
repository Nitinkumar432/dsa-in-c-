// Online C++ compiler to run C++ program online
#include <iostream>
#include<string>
using namespace std;

class hero{
    private:
    int salary;
    public:
    int h;
    string emp_name;
    int emp_id;
    void setsalary(int s){
        salary=s;
    }
    int getsalary(){
        return salary;
    }
    void sethealth(int n){
        h=n;
        
    }
    int gethealth(){
        return h;
    }
    
};
int main() {
    hero *b = new hero;
    (*b).emp_name="Nitin";
    (*b).emp_id=221099;
    b->setsalary(1000);
    cout<<(*b).getsalary()<<endl;
    b->sethealth(5);
    cout<<b->gethealth()<<endl;
    cout<<(*b).emp_name<<endl;
    cout<<b->emp_id<<endl;
        
    
   

    return 0;
}
