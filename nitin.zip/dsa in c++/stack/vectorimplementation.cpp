#include<iostream>
#include<vector>
using namespace std;

class Stack {
    //properties
public:
    vector<int> arr; // Change from int* to vector<int>
    int top;
    int size;

    // behaviour
    Stack(int size) {
        this -> size = size;
        top = -1;
    }

    void push(int element) {
        if(size - top > 1) {
            top++;
            arr.push_back(element); // Pushing the element to the vector
        }
        else{
            cout << "Stack OverFlow" << endl;
        }
    }

    void pop() {
        if(top >= 0) {
            arr.pop_back(); // Remove the last element in the vector
            top--;
        }
        else{
            cout << "Stack UnderFlow" << endl;
        }
    }

    int peek() {
        if(top >= 0)
            return arr[top];
        else {
            cout << "Stack is Empty" << endl;
            return -1;
        }
    }

    bool isEmpty() {
        return top == -1;
    }
};


int main() {
    Stack st(5);

    st.push(22);
    st.push(43);
    st.push(44);
    st.push(22);
    st.push(43);
    st.push(44); // This will result in Stack Overflow

    cout << st.peek() << endl;

    st.pop();

    cout << st.peek() << endl;

    st.pop();

    cout << st.peek() << endl;

    st.pop();

    cout << st.peek() << endl;

    if(st.isEmpty()) {
        cout << "Stack is Empty mere dost " << endl;
    }
    else {
        cout << "Stack is not Empty mere dost " << endl;
    }
}

