#include<iostream>
#include<stack>
#include<string>
using namespace std;

int main(){
     string a;
    cin >> a;
    stack<char> m;
    for(int i = 0; i < a.length(); i++){
        char ch=a[i];
        m.push(a[i]); // Convert char to string
    }
    
string ans="";
    while(!m.empty()){
ans.push_back(m.top());
        cout << m.top();
        m.pop();
        
    }
    cout<<"after that"<<ans<<endl;
}
