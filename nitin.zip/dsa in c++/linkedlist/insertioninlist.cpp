#include<iostream>
using namespace std;
class Node{
    public:
    int data; //12
    Node* next; //address
    Node(int data){
        this->data=data; //12
        this->next=NULL; //10;
    }
    

};
void insertathead(Node* &head,int d){ // 10 | NULL
    Node *temp=new Node(d); // // 12
    temp->next=head; // 10
    head=temp;
}
void print(Node* head){ // 
    Node* temp=head;// 112 10 NULL
    /*
    ------------
    10 | NULL
    ------------
    */
    while(temp!=NULL){ //10;
        cout<<temp->data<<" ";
        temp=temp->next; //NULL

    }
    cout<<endl;
}
int main(){
    Node* n1=new Node(10); //10
    Node* head=n1;// head=10;
 /** Head  ------------
    10 |   NULL
    ------------*/
    print(head);// 10;
    insertathead(head,12); // 10 | NULL
    print(head);

}