// Online C++ compiler to run C++ program online
#include <iostream>
using namespace std;

class node{
    public:
    int data;
    node *next;
    node(int d){
        this->data=d;
        next=NULL;
    }
    
    
};
void insert(node* & head,int val){
    node *temp=new node(val);
  head->next=temp;
  head=temp;

    // temp->next=temp;
   
}
void display(node *h){
    node *temp=h;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}



int main() {
    node *h1=new node(12344);
    // cout<<head->data<<endl;
    // cout<<head->next;
    // head=NULL;
    node *headrm=h1;
    node *tail=h1; //12344
    insert(headrm,34);
     insert(headrm,344);
    display(tail);
    // head=NULL;
    // cout<<head->data<<endl;
    
    
 

    return 0;
}