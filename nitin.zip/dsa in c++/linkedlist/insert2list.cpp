#include<iostream>
using namespace std;
class node{
    public:
    int data;
    node *next;
    node(int data){
        this->data=data;
        this->next=NULL;
    }
};
/*adding element at starting */
void insertathead(node*&head,int d){
    node*temp=new node(d); //
    temp->next=head;
    head=temp;


}
void insertattail(node*tail,int v){
    node*temp=new node(v);
    tail->next=temp;
    tail=tail->next;
}
/*printting thr value**/
void print(node*head){
    node*temp=head;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;

    }
    cout<<endl;


}

int main(){
    node* n1=new node(10);
    cout<<n1->data<<endl;
    cout<<n1->next<<endl;
    cout<<endl;
    node*head=n1;
    node*tail= n1;
    insertathead(head ,20);
    print(head);
    insertattail(tail,20);
    /*print value after add element*/
    
     /*print value after add element*/
    print(tail);


   
  
}