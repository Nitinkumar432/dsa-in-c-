#include<iostream>
using namespace std;

class node {
public:
    int val;
    node* next;
    node(int v) {
        this->val = v;
        this->next = NULL;
    }
};

void insertAtTail(node*& head, int vm) {
    node* temp = new node(vm);
    if (head == nullptr) { 
        head = temp; // If the list is empty, make the new node the head
        return;
    }
    node* curr = head;
    while (curr->next != NULL) {
        curr = curr->next;
    }
    curr->next = temp; 
}

int length(node *head) {
    node* temp = head;
    int c = 0;
    while (temp != NULL) {
        c++;
        temp = temp->next;
    }
    return c;
}

void deleteatkth(node*& head, int k) {
    int n = length(head);
    cout << "Length of the list: " << n << endl;

    // Check if position k is valid
    if (k <= 0 || k > n) {
        cout << "Invalid position" << endl;
        return;
    }

    node* temp = head;
    int pos = 0;
    while (pos != n - k-1) {
        temp = temp->next;
        pos++;
    }

    // node* delNode = temp->next;
    temp->next = temp->next->next;
    // delete delNode; // Free the memory of the deleted node
}

void display(node* head) {
    node* temp = head;
    while (temp != nullptr) {
        cout << temp->val << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    node* m1 = nullptr; // Create an empty list m1
   
    // Insert elements into m1
    insertAtTail(m1, 10);
    insertAtTail(m1, 20);
    insertAtTail(m1, 30);
    insertAtTail(m1, 40);
    insertAtTail(m1, 50);
   
    display(m1);
    deleteatkth(m1, 2);
    display(m1);

    return 0;
}
