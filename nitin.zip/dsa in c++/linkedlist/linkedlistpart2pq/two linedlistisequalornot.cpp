// #include<iostream>
// using namespace std;

// class node {
// public:
//     int val;
//     node* next;
//     node(int v) {
//         this->val = v;
//         this->next = NULL;
//     }
// };

// void insertath(node*& head, int val) {
//     node* temp = new node(val);
//     node*current=head;
//     current->next = temp; // Make the new node point to the current head
//     current = temp;       // Update the head to the new node
// }

// void display(node* head) {
//     node* temp = head;
//     while (temp != NULL) {
//         cout << temp->val << " ";
//         temp = temp->next;
//     }
//     cout << endl;
// }

// int main() {
//     node* m1 = NULL;
//     node* m2 = NULL;
//     node*n1=m1;
//     node*n2=m2;
    
//     insertath(m1, 10);
//     insertath(m1, 20);
//     insertath(m1, 30);
//     insertath(m1, 40);
//     insertath(m1, 50);
//     display(m1);
    
//     cout << "push in another" << endl;
    
//     insertath(m2, 10);
//     insertath(m2, 30);
//     insertath(m2, 20);
//     insertath(m2, 400);
//     insertath(m2, 50);
         
//     display(n1); // Display m1 instead of m2
// }
#include<iostream>
using namespace std;

class node {
public:
    int val;
    node* next;
    node(int v) {
        this->val = v;
        this->next = NULL;
    }
};

void insertAtTail(node*& head,  int val) {
    node* temp = new node(val);
    if(head==nullptr){
        head=temp;
        return ;
    }
    node*curr=head;
    while(curr->next!=nullptr){
        curr=curr->next;
    }
    curr->next=temp;
}


void display(node* head) {
    node* temp = head;
    
    while (temp != nullptr) {
        cout << temp->val << " ";
        temp = temp->next;
    }
    cout << endl;
}
bool check(node*head1,node*head2){
    node*p1=head1;
    node*p2=head2;
    while(p1!=nullptr && p2!=nullptr){
        if(p1->val!=p2->val){
            return 0;
        }
        p1=p1->next;
        p2=p2->next;

    }
    return (p1==NULL && p2==NULL);
}

int main() {
    node* m1 = nullptr; // Create an empty list m1
    node* m2 = nullptr; // Create an empty list m2
    
    // Insert elements into m1
    insertAtTail(m1, 10);
    insertAtTail(m1, 20);
    insertAtTail(m1, 30);
    insertAtTail(m1, 40);
    insertAtTail(m1, 50);
    
    cout << "push in another" << endl;
    
    // Insert elements into m2
    insertAtTail(m2, 10);
    insertAtTail(m2, 20);
    insertAtTail(m2, 30);
    insertAtTail(m2, 40);
    // insertAtTail(m2, 50);
    
    // Display m1
    cout << "m1: ";
    display(m1);
    
    // Display m2
    cout << "m2: ";
    display(m2);
    if(check(m1,m2)){
        cout<<1<<endl;
    }else{
        cout<<0<<endl;
    }
    
    return 0;
}
