#include <iostream>
using namespace std;

class ListNode {
public:
    int val;
    ListNode* next;
    ListNode(int x) : val(x), next(nullptr) {}
};

int length(ListNode* head) {
    int len = 0;
    while (head != nullptr) {
        len++;
        head = head->next;
    }
    return len;
}

ListNode* getIntersectionNode(ListNode* headA, ListNode* headB) {
    int lenA = length(headA);
    int lenB = length(headB);
    
    // Move the longer list pointer by the difference in lengths
    while (lenA > lenB) {
        headA = headA->next;
        lenA--;
    }
    while (lenB > lenA) {
        headB = headB->next;
        lenB--;
    }
    
    // Traverse both lists until a common node is found
    while (headA != nullptr && headB != nullptr) {
        if (headA == headB)
            return headA; // Found the intersection point
        headA = headA->next;
        headB = headB->next;
    }
    
    return nullptr; // No intersection found
}

int main() {
    // Example usage
    ListNode* intersectNode = new ListNode(8);
    
    ListNode* headA = new ListNode(4);
    headA->next = new ListNode(1);
    headA->next->next = intersectNode;
    intersectNode->next = new ListNode(4);
    intersectNode->next->next = new ListNode(5);
    
    ListNode* headB = new ListNode(5);
    headB->next = new ListNode(6);
    headB->next->next = new ListNode(1);
    headB->next->next->next = intersectNode;
    
    ListNode* intersection = getIntersectionNode(headA, headB);
    
    if (intersection)
        cout << "Intersection point value: " << intersection->val << endl;
    else
        cout << "No intersection point found" << endl;
    
    return 0;
}
