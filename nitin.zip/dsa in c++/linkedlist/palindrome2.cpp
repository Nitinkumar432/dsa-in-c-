#include<iostream>
using namespace std;

class node {
public:
    int val;
    node* next;
    node(int v) {
        this->val = v;
        this->next = nullptr; // Initialize next to nullptr
    }
};

void break1(node*& head, int n) {
    int pos = 0; //1 2 3 4 5 
    while (pos != n && head != nullptr) { // Check if head is not nullptr
        head = head->next;
        pos++;
    }
}

void insertatt(node*& head, int d) {
    node* temp = new node(d);
    if (head == nullptr) {
        head = temp;
        return;
    }
    node* curr = head;
    while (curr->next != nullptr) {
        curr = curr->next;
    }
    curr->next = temp; // Connect the last node to the new node
}

void display(node* head) {
    node* temp = head;
    while (temp != nullptr) {
        cout << temp->val << " ";
        temp = temp->next;
    }
    cout << endl;
}

int length(node* head) {
    int c = 0;
    node* temp = head;
    while (temp != nullptr) {
        c++;
        temp = temp->next;
    }
    return c;
}

// int findmiddle(node* head) {
//     int n = length(head);

//     int pos = 0;

//     node* temp = head;
//     while (pos != n / 2 - 1 && temp != nullptr) { // Check if temp is not nullptr
//         pos++;
//         temp = temp->next;
//     }
//     if (temp != nullptr && temp->next != nullptr) {
//         return temp->next->val;
//     }
//     return -1; // Return -1 if the middle node cannot be found
// }

int check(node* h1, node* h2, int n) {
    int pos = 0;
    while (pos != n) {
        if (h1->val != h2->val) {
            return 0;
        }
        h1 = h1->next;
        h2 = h2->next;
        pos++;
    }
    return 1;
}

void rev(node*& head) {
    node* prev = nullptr;
    node* curr = head;
    while (curr != nullptr) {
        node* next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    head = prev;
}

int main() {
    node* n1 = nullptr;
    insertatt(n1, 1);
    insertatt(n1, 0);
    // insertatt(n1, 2);
    // insertatt(n1, 1);

    display(n1);

    int n = length(n1);
    node* n2 = n1;

    if (n % 2 == 0) {
        break1(n2, n / 2);
    }
    else {
        break1(n2, n / 2 + 1);
    }

    node* m2 = n2;
    rev(n2);
    cout << "after reverse " << endl;
    display(m2);

    int d = length(n2);
    if (check(n1, n2, d)) {
        cout << "true" << endl;
    }
    else {
        cout << "false" << endl;
    }

    cout << "element in n2 after break " << endl;
    display(n2);

    return 0;
}
