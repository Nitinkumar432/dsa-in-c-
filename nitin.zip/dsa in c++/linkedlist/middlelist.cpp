#include<iostream>
using namespace std;

class node{
    public:
    int val;
    node*next;
    node(int v){
        this->val=v;
        this->next=next;
    }
};
void insertatt(node*&head,int d){
    node*temp=new node(d);
    if(head==nullptr){
        head=temp;
        return;
    }
    node*curr=head;
    while(curr->next!=NULL){
        curr=curr->next;
    }
    curr->next=temp;
}
void display(node*head){
    node*temp=head;
    while(temp!=NULL){
        cout<<temp->val<<" ";
        temp=temp->next;
    }
    cout<<endl;
}
int length(node*head){
    int c=0;
    node*temp=head;
    while(temp!=NULL){
        c++;
        temp=temp->next;

    }
    return c;
}
int  findmiddle(node*head){
    int n=length(head);
  
    int pos=0;
    int v;
    node*temp=head; // 10 20 30 40 50 / 2
    while(pos!=n/2-1){
       
        pos++;
        temp=temp->next;

    }
     return temp->next->val;
}

int main(){
    node*n1=nullptr;
    insertatt(n1,10);
    insertatt(n1,20);
    insertatt(n1,30);
    insertatt(n1,40);
    insertatt(n1,50);
    insertatt(n1,70);
    insertatt(n1,80);
        insertatt(n1,90);
    insertatt(n1,100);
    // cout<<"middel value is "<<findmiddle(n1);
    display(n1);
   
    cout<<"middel value is : "<<findmiddle(n1);
}