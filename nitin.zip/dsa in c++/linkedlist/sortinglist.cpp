#include<iostream>
using namespace std;

class node {
public:
    int val;
    node* next;
    node(int v) {
        this->val = v;
        this->next = NULL;
    }
};
void insertAtTail(node*& head,  int val) {
    node* temp = new node(val);
    if(head==nullptr){
        head=temp;
        return ;
    }
    node*curr=head;
    while(curr->next!=nullptr){
        curr=curr->next;
    }
    curr->next=temp;
}


void display(node* head) {
    node* temp = head;
    
    while (temp != nullptr) {
        cout << temp->val << " ";
        temp = temp->next;
    }
    cout << endl;
}
int length(node*head){
    int c=0;
    node*temp=head;
    while(temp!=NULL){
        c++;
        temp=temp->next;

    }
    return c;

}
void bubblesort(node*&head){
    int n=length(head);
 
    if(n<=1){
        return ;

    }
    bool swap;
    do{
        swap=false;
        node*ptr=head;
        while(ptr->next!=NULL){
            if(ptr->val>ptr->next->val){
                int temp=ptr->val;
                ptr->val=ptr->next->val;
                ptr->next->val=temp;
                swap=true;


            }
            ptr=ptr->next;
        }
    }while(swap);
}
int main() {
    node* m1 = nullptr; // Create an empty list m1
   
    // Insert elements into m1
    insertAtTail(m1, 10);
    insertAtTail(m1, 20);
    insertAtTail(m1, 300);
    insertAtTail(m1, 20);
    insertAtTail(m1, 50);
    display(m1);
    bubblesort(m1);
    display(m1);
}