#include<iostream>
using namespace std;
class node{
    public:
    int data;
     node*next;
    node(int d){
        data=d;
        next=NULL;
    }

};
void insertattail(node* &head,int val){
    node*temp= new node(val);
    head->next=temp;
   head=temp;

}
void deleteatpos(node* &head,int pos){
    node*temp=head;
   
    int p=0;
    while(p!=pos-1){ // 10 20 30 40  50 60
     
        temp=temp->next;
        
        p++;
    }
    // node*t=temp->next; //40;
   temp->next=temp->next->next;
//    free(t);
    // 10 20 30 40 50 60
}
void display(node*head){
    node*temp=head;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;

    }
    cout<<"NULL";
}
int main(){
    node *n1=new node(10);
    node*tail=n1;
    node*head=n1;
    insertattail(head,20);
    insertattail(head,30);
    insertattail(head,40);
    insertattail(head,50);
    insertattail(head,60);
    deleteatpos(tail,3);
    display(tail);


}