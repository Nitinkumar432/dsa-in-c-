#include<bits/stdc++.h>
using namespace std;
class node{
    public:
    int val;
    node*next;
   node(int v){
        this->val=v;
        this->next=next;
    }

};
void insertattail(node*&head,int d){
    node*temp=new node(d);
    head->next=temp;
    head=temp;
}
void display(node*head){
    node*temp=head;
    while(temp!=NULL){
        cout<<temp->val<<" ";
        temp=temp->next;
    }
    cout<<endl;
}
// cout<<"after recursion"<<endl;
void recursion(node*head){
    if(head==NULL){
        return ;
    }
    recursion(head->next);
    cout<<head->val<<endl;
}
int main(){
    node*n1=new node(10);
    node*tail=n1;
    node*head=n1;
insertattail(head,20);
insertattail(head,30);
 insertattail(head,40);
 insertattail(head,50);
 insertattail(head,60);
 insertattail(head,70);
 display(tail);
 recursion(tail);

}