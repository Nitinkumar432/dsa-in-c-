#include<iostream>
using namespace std;

class node{
    public:
    int val;
    node*next;
    node(int v){
        this->val=v;
        this->next=next;
    }
};

void insertatt(node*&head,int d){
    node*temp=new node(d);
    if(head==nullptr){
        head=temp;
        return;
    }
    node*curr=head;
    while(curr->next!=NULL){
        curr=curr->next;
    }
    curr->next=temp;
}
void display(node*head){
    node*temp=head;
    while(temp!=NULL){
        cout<<temp->val<<" ";
        temp=temp->next;
    }
    cout<<endl;
}
int length(node*head){
    int c=0;
    node*temp=head;
    while(temp!=NULL){
        c++;
        temp=temp->next;

    }
    return c;
}
void odd(node*&head){
   //1 2 3 4 5 6
    node*evenhead=head->next; 2
    node*oddptr=head; //1 
    node*evenptr=evenhead; // 2
    while(evenptr && evenptr->next){
        oddptr->next=oddptr->next->next;
         evenptr->next=evenptr->next->next;
         oddptr=oddptr->next;
         evenptr=evenptr->next;

    }
    oddptr->next=evenhead;
    
}



int main(){
    node*n1=nullptr;
    insertatt(n1,1);
    insertatt(n1,2);
    insertatt(n1,3);
    insertatt(n1,4);
    insertatt(n1,5);
    insertatt(n1,6);
    // insertatt(n1,30);
    //     insertatt(n1,20);
    // insertatt(n1,10);
    
    // node*m1=n1;
    //4 9/2
    cout<<"element in n2 after break "<<endl;
    // display(n1);
    odd(n1);
    display(n1);
    // even(n1);
    //   cout<<"length of linked dis "<<n<<endl;
   
    // cout<<"middel value is : "<<findmiddle(n1);
}