#include<iostream>
using namespace std;
class node{
    public:
    int data;
    node *next;
    node(int d){
       data=d;
        next=NULL;
    }

};
void insert(node* &head,int val){ // null
    node *temp=new node(val);
    temp->next=head;
    head=temp;
}
void display(node*head){
    node *temp=head;
    while(temp!=NULL){
        cout<<temp->data<<"-> ";
        temp=temp->next;
    }
    cout<<"NULL"<<endl;
    

}
int main(){
    node * n1=new node(10);
    cout<<n1->data<<endl;
    node *head=n1;
    insert(head,20);
    display(head);


}