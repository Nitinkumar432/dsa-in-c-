#include<iostream>
using namespace std;

class node{
    public:
    int data;
    node*next;
    node(int v){
        this->data=v;
        this->next=next;
    }

};
void insertattail(node* & head,int val){
    node*temp=new node(val);
    head->next=temp;
    head=temp;

}
void deletealter(node*&head){
node* current = head; // 100 200 300 400 500 600
    while (current != NULL && current->next != NULL) {
        node* temp = current->next; //200
        current->next = temp->next; //300
        delete temp;//00
        current = current->next;  //300// Move to the next node
    }
}
void display(node*head){
    node*temp=head;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

int main(){
    node*n1=new node(100);
    node*tail=n1;
    node*head=n1;
    insertattail(head,200);
    insertattail(head,300);
    insertattail(head,400);
    insertattail(head,500);
    insertattail(head,600);
    deletealter(tail);
    display(tail);

}