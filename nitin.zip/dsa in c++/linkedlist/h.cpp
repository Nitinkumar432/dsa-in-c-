#include<iostream>
using namespace std;
class m{
    public:
    int data;
    m* next;
    m(int data){
        this->data=data;
        this->next=NULL;
    }


};
int main(){
    m *n1=new m(100);
    cout<<n1->data<<endl;
    cout<<n1->next<<endl;

 
}