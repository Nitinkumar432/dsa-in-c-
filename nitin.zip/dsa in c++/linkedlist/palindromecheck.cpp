#include<iostream>
using namespace std;

class node{
    public:
    int val;
    node*next;
    node(int v){
        this->val=v;
        this->next=next;
    }
};
void break1(node*&head,int n){
    int pos=0; //1 2 3 4 5 
    while(pos!=n){ 
        head=head->next;
        pos++;
    }
    // head=head->next;
}
void insertatt(node*&head,int d){
    node*temp=new node(d);
    if(head==nullptr){
        head=temp;
        return;
    }
    node*curr=head;
    while(curr->next!=NULL){
        curr=curr->next;
    }
    curr->next=temp;
}
void display(node*head){
    node*temp=head;
    while(temp!=NULL){
        cout<<temp->val<<" ";
        temp=temp->next;
    }
    cout<<endl;
}
int length(node*head){
    int c=0;
    node*temp=head;
    while(temp!=NULL){
        c++;
        temp=temp->next;

    }
    return c;
}
int  findmiddle(node*head){
    int n=length(head);
  
    int pos=0;
    
    node*temp=head; // 10 20 30 40 50 / 2
    while(pos!=n/2-1){
       
        pos++;
        temp=temp->next;

    }
     return temp->next->val;
}
int  check(node*h1,node*h2,int n){
    int pos=0;
    while(pos!=n){
        if(h1->val!=h2->val){
            return 0;


        }
        h1=h1->next;
        h2=h2->next;
        pos++;
    }
    return 1;
}
void rev(node*&head){
    node*prev=NULL;
    node*curr=head;
    while(curr!=NULL){
        node*next=curr->next;
        curr->next=prev;
        prev=curr;
        curr=next;
    }
    head=curr;
}
int main(){
    node*n1=nullptr;
    insertatt(n1,1);
    insertatt(n1,2);
    insertatt(n1,10);
    insertatt(n1,1);
    // insertatt(n1,50);
    // insertatt(n1,40);
    // insertatt(n1,30);
    //     insertatt(n1,20);
    // insertatt(n1,10);
    // cout<<"middel value is "<<findmiddle(n1);
    display(n1);
    int n=length(n1);
    node*n2=n1;
    // node*n3=n1;
    if(n%2==0){
    break1(n2,n/2);
    }else{
        break1(n2,n/2+1);
    } 
    node*m2=n2;
    display(n2);
    rev(n2);
    cout<<"after reverse "<<endl;
    display(m2);
    int d=length(n2);
    if(check(n1,n2 , d)){
        cout<<"true"<<endl;
    }else{
        cout<<"false"<<endl;
    }

    //4 9/2
    cout<<"element in n2 after break "<<endl;
    display(n2);
    //   cout<<"length of linked dis "<<n<<endl;
   
    // cout<<"middel value is : "<<findmiddle(n1);
}