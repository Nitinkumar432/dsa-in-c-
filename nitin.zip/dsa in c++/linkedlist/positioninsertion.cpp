#include<iostream>
using namespace std;

class node {
public:
    int data;
    node *next;

    // Constructor to initialize data and next pointer
    node(int d) {
        this->data = d;
        this->next = NULL;
    }
};

// Function to insert a node at the end of the linked list
void insert(node* &head, int v) {
    node *temp = new node(v);
    head->next = temp;
    head = temp;
}

// Function to insert a node at a specific position in the linked list
void insertat(node* &head, int v, int pos) {
    if (pos == 0) {
        insert(head, v);
    }
    node *new_n = new node(v);
    node *temp = head;
    int s = 0;
    while (s != pos - 1) {
        temp = temp->next;
        s++;
    }
    new_n->next = temp->next;
    temp->next = new_n;
}

// Function to display the elements of the linked list
void display(node* head) {
    node *temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
}

int main() {
    node *n1 = new node(100);
    node *head = n1;
    node *m = n1;
    insert(head, 200);
    insert(head, 300);
    insert(head, 400);
    insert(head, 500);
    insertat(m, 5, 1); // Inserting 5 at position 1
    display(m); // Displaying the linked list
}
