#include<iostream>
using namespace std;
class node{
    public:
    int data;
     node*next;
    node(int d){
        data=d;
        next=NULL;
    }

};
void insertattail(node* &head,int val){
    node*temp= new node(val);
    head->next=temp;
   head=temp;

}
void deleteatdup(node* &he){
    node*temp=he; //1 2 2 3 3 3
    while(temp!=NULL && temp->next!=NULL){
        if(temp->data==temp->next->data){
          // Save the pointer to the duplicate node
            temp->next = temp->next->next; // Update the next pointer of the current node to skip the duplicate node
        
        //    temp==temp->next;
          

        }else{
            temp=temp->next;
        }
    }


}

void display(node*head){
    node*temp=head;

    while(temp!=NULL){
      
        cout<<temp->data<<endl;
        temp=temp->next;
    }
}
int main(){
    node *n1=new node(10);
    node *m=n1;
    node*head=n1;
    insertattail(head,20);
     insertattail(head,20);
      insertattail(head,40);
       insertattail(head,50);
       insertattail(head,50);
        deleteatdup(m);
        // display(m);
   
    display(m);
}