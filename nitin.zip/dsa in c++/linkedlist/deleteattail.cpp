#include<iostream>
using namespace std;
class node{
    public:
    int data;
     node*next;
    node(int d){
        data=d;
        next=NULL;
    }

};
void insertattail(node* &head,int val){
    node*temp= new node(val);
    head->next=temp;
   head=temp;

}
void deleteattail(node* &he){
   node*temp=he;
   while(temp->next->next!=NULL){
      temp=temp->next;
   }
   node*temp2=temp->next;
   temp->next=NULL;
}

void display(node*head){
    node*temp=head;

    while(temp!=NULL){
      
        cout<<temp->data<<endl;
        temp=temp->next;
    }
}
int main(){
    node *n1=new node(10);
    node *m=n1;
    node*head=n1;
    insertattail(head,20);
     insertattail(head,30);
      insertattail(head,40);
       insertattail(head,50);
        deleteattail(m);
        // display(m);
   
    display(m);




}