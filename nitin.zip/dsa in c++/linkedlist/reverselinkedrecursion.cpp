// #include<bits/stdc++.h>
// using namespace std;
// class node{
//     public:
//     int val;
//     node*next;
//    node(int v){
//         this->val=v;
//         this->next=next;
//     }

// };
// void insertattail(node*&head,int d){
//     node*temp=new node(d);
//     head->next=temp;
//     head=temp;
// }
// void display(node*head){
//     node*temp=head;
//     while(temp!=NULL){
//         cout<<temp->val<<" ";
//         temp=temp->next;
//     }
//     cout<<endl;
// }
// // cout<<"after recursion"<<endl;
// void reverse(node*& head) {
//     if (head == NULL || head->next == NULL) {
//         // If the list is empty or has only one node, it's already reversed (or doesn't need reversal)
//         return;
//     }

//     // Recursively reverse the rest of the list
//     reverse(head->next);

//     // Adjusting pointers to reverse the list
//     node* rest = head->next;
//     head->next->next = head;
//     head->next = NULL;

//     // Updating head to the new head of the reversed list
//     head = rest;
// }


// int main(){
//     node*n1=new node(10);
    
//     node*head=n1;
//     node*tail=head;
// insertattail(head,20);
// insertattail(head,30);
//  insertattail(head,40);
//  insertattail(head,50);
//  insertattail(head,60);
//  insertattail(head,70);
//  display(head);
//  reverse(tail);
//  display(tail);

// }
#include<bits/stdc++.h>
using namespace std;

class node{
public:
    int val;
    node* next;

    node(int v){
        this->val = v;
        this->next = nullptr; // Corrected to initialize next as nullptr
    }
};

void insertAtTail(node*& head, int d){
    node* temp = new node(d);
    if (head == nullptr) {
        head = temp;
    } else {
        node* tail = head;
        while (tail->next != nullptr) {
            tail = tail->next;
        }
        tail->next = temp;
    }
}

void display(node* head){
    while(head != nullptr){
        cout << head->val << " ";
        head = head->next;
    }
    cout << endl;
}

void reverse(node*& head) {
    if (head == nullptr || head->next == nullptr) {
        return;
    }

    node* rest = head->next;
    reverse(rest);

    head->next->next = head;
    head->next = nullptr;

    head = rest;
}

int main(){
    node* head = nullptr;

    insertAtTail(head, 10);
    insertAtTail(head, 20);
    insertAtTail(head, 30);
    insertAtTail(head, 40);
    insertAtTail(head, 50);
    insertAtTail(head, 60);
    insertAtTail(head, 70);

    cout << "Original list: ";
    display(head);

    reverse(head);

    cout << "Reversed list: ";
    display(head);

    return 0;
}
