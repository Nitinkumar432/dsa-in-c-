#include<iostream>
using namespace std;

class node {
public:
    int val;
    node* next;
    node(int v) {
        this->val = v;
        this->next = NULL;
    }
};
void insertAtTail(node*& head,  int val) {
    node* temp = new node(val);
    if(head==nullptr){
        head=temp;
        return ;
    }
    node*curr=head;
    while(curr->next!=nullptr){
        curr=curr->next;
    }
    curr->next=temp;
}


void display(node* head) {
    node* temp = head;
    
    while (temp != nullptr) {
        cout << temp->val << " ";
        temp = temp->next;
    }
    cout << endl;
}
int length(node*head){
    int c=0;
    node*temp=head;
    while(temp!=NULL){
        c++;
        temp=temp->next;

    }
    return c;

}
void bubblesort(node*&head){
    int n=length(head);
 
    if(n<=1){
        return ;

    }
    bool swap;
    do{
        swap=false;
        node*ptr=head;
        while(ptr->next!=NULL){
            if(ptr->val>ptr->next->val){
                int temp=ptr->val;
                ptr->val=ptr->next->val;
                ptr->next->val=temp;
                swap=true;


            }
            ptr=ptr->next;
        }
    }while(swap);
}
int main() {
    node* m1 = nullptr;
    node*m2=nullptr;
    node*m3=nullptr;  // Create an empty list m1
   
    // Insert elements into m1
    insertAtTail(m1, 10);
    insertAtTail(m1, 20);
    insertAtTail(m1, 300);
    insertAtTail(m1, 20);
    insertAtTail(m1, 50);
     insertAtTail(m2, 100);
    insertAtTail(m2, 209);
    insertAtTail(m2, 3070);
    insertAtTail(m2, 208);
    insertAtTail(m2, 500);
        insertAtTail(m3, 10);
    insertAtTail(m3, 29);
    insertAtTail(m3, 370);
    insertAtTail(m3, 82);
    insertAtTail(m3, 50);
    display(m1);
    display(m2);
    display(m3);
   cout<< "after putting value there "<<endl;
   while(m2!=NULL){
    insertAtTail(m1,m2->val);
    m2=m2->next;
   }
   while(m3!=NULL){
    insertAtTail(m1,m3->val);
    m3=m3->next;
   }
   display(m1);
    bubblesort(m1);
    display(m1);
}