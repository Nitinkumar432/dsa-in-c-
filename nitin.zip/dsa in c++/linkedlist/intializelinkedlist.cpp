#include<iostream>
using namespace std;
class m{
    public:
    int data;
    Node* next;
    Node(){
        this->data=data;
        this->next=next;
    }


};
int main(){
    Node *n1=new Node();
    cout<<this->data<<endl;
    cout<<this->next<<endl;

}