#include<iostream>
using namespace std;
class node{
    public:
    int data;
    node*next;
    node(int d){
        data=d;
        next=NULL;
    }
};
void insertatt(node*&head,int val){
    node*temp=new node(val);
    head->next=temp;
    head=temp;



}
void insertath(node*&head,int val){
    node*temp=new node(val);
    temp->next=head;
    head=temp;



}
void display(node* head){
    node*temp=head;
    
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    cout<<endl;
}

void insertatposition(node*head,int val,int pos){
      node*new_n=new node(val);
      node*temp=head;
    if(pos==0){
        insertath(head,val);
    }
    int i=0;
    while(i!=pos-1){
        temp=temp->next;
        i++;
    }
    new_n->next=temp->next;
    temp->next=new_n;
    

  
}
int main(){
    node*n1=new node(10);
    // cout<<n1->data<<endl;
      node*m=n1;
   node*head=n1;
 
    insertatt(head,45);
    insertatt(head,30);
    // display(tail);
    display(m);
    insertatposition(m,40,1);
    display(m);

    // cout<<n1->next<<endl;
    
}