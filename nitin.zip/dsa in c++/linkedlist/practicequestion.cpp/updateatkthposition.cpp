#include<iostream>
using namespace std;
class node{
    public:
    int data;
     node*next;
    node(int d){
        data=d;
        next=NULL;
    }

};
void insertattail(node* &head,int val){
    node*temp= new node(val);
    head->next=temp;
   head=temp;

}

void display(node*head){
    node*temp=head;

    while(temp!=NULL){
      
        cout<<temp->data<<endl;
        temp=temp->next;
    }
}
int main(){
    node*n1=new node(100);
    node*tail=n1;
    node *head=n1;
    insertattail(head,200);
    insertattail(head,300);
    insertattail(head,400);
    insertattail(head,500);
    // insertatpos(head,2,3000);
    display(tail);
}