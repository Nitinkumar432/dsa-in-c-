#include<iostream>
using namespace std;
class node{
    public:
    int val;
    node*next;
    node(int v){
        this->val=v;
        this->next=next;
    }
};
void insertathead(node*&head,int vf){
    node*temp=new node(vf);
    head->next=temp;
    head=temp;
}
void insertatposition(node* &head,int g,int pos){
   node*new_n=new node(g);
   node*temp=head;
   int p=0;
   while(p!=pos-1){
    temp=temp->next;
    p++;
   }
   new_n->next=temp->next;
   temp->next=new_n;
}
void insert_pos(node*head,int f,int value){
    node*temp=head;
    int pos=0;
    while(pos!=f){
        temp=temp->next;
        pos++;
    }
    temp->val=value;
}


void display(node*head){
    node*temp=head;
    while(temp!=NULL){
        cout<<temp->val<<" ";
        temp=temp->next;
    }
}
int main(){
    node *n1=new node(50);
    cout<<n1->val<<endl;
    node*tail=n1;
    node*head=n1;
    insertathead(head ,1);
    insertathead(head ,2);
    insertathead(head ,3);
     insertatposition(tail ,45,2);
     insert_pos(tail,2,34);
    display(tail);
    
}