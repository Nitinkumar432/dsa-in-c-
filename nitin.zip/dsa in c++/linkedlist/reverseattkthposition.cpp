#include<iostream>
using namespace std;
class node{
    public:
    int val;
    node*next;
    node(int v){
        val=v;
        next=NULL;
    }
};
void insert(node* & head,int value){
    node *temp=new node(value);
  head->next=temp;
  head=temp;

    // temp->next=temp;
   
}
void reverse(node*&head){
    node*prev=NULL;
    node*curr=head;
    while(curr!=NULL){
        node*next=curr->next;
        curr->next=prev;
        prev=curr;
        curr=next;
    }
    head=prev;
}
void  swap(node*&head,int k){
    node*prev=NULL;
    node*curr=head;
    int c=0;
    while(curr!=NULL && c<k){
        node*next=curr->next;
        curr->next=prev;
        prev=curr;
        curr=next;
        c++;
    }
    if(curr!=NULL ){
    swap(curr,k);
    head->next=curr;
    head=prev;
    }
}
void display(node *h){
    node *temp=h;
    while(temp!=NULL){
        cout<<temp->val<<" ";
        temp=temp->next;
    }
    cout<<endl;
}

int main(){

node*n=new node(10);

node*tail=n;
node*head=n;
insert(head,20);
insert(head,30);
insert(head,40);
insert(head,50);
insert(head,60);
display(tail);
cout<<"after reversing "<<endl;;
reverse(tail);
display(head);
cout<<":after swaping at kth p"<<endl;
swap(n,2);
display(tail);



}