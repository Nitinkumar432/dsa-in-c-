#include<iostream>
using namespace std;
class node{
    public:
    int data; //10
    node* next;
    node(int data){
        this->data=data; //20;
        this->next=next; // 20
    }



};
void insertath(node *&head,int v){
    node *temp=new node(v); // 20
    temp->next=head;
    head=temp;
}
void print(node*head){
    node*temp=head;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
        
    }
    cout<<endl;
}

int main(){
    node *n1=new node(10);
    cout<<n1->data<<endl;
    node *head=n1;
    insertath(head,20);
    print(head);

}