// Online C++ compiler to run C++ program online
#include <iostream>
using namespace std;
class nitin{
    private:
    int health;
    public:
    nitin(int health){
        
       this->health=health;
        cout<<this<<endl;
    }
   
    
};
int main() {
    nitin m1(20);
     cout<<&m1<<endl;
// nitin *h1 =new nitin;
 
  
    return 0;
}
